# helpdesk
Vamos criar um sistema para auxiliar a registrar ocorrências de uma empresa helpdesk

# integrantes
Pedro Henrique Miguel da Silva
Murilo Andrade Guedes Pereira Máximo
Gabriel Lucas Oliveira Brito
