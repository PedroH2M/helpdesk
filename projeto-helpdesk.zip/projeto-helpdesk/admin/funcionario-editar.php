<?php

    require_once "config.inc.php";

    $id = $_POST['id'];
    $nome = $_POST['nome']; 
    $matricula = $_POST['matricula']; 
    $email = $_POST['email']; 
    $funcao = $_POST['funcao'];
    $usuario = $_POST['usuario'];
    $senha_usuario = $_POST['senha_usuario'];

    $sql = "UPDATE usuarios SET
            nome = '$nome',
            matricula = '$matricula',
            email = '$email',
            funcao = '$funcao',
            usuario = '$usuario',
            senha_usuario = '$senha_usuario'
            WHERE id = '$id'";

    if(mysqli_query($conexao, $sql)){
        echo "<script>alert('Funcionário atualizado com sucesso!'); window.location.href='../area-gestor.php';</script>";
    } else {
        echo "<script>alert('Erro ao atualizar!'); window.location.href='../area-gestor.php';</script>";
    }

?>