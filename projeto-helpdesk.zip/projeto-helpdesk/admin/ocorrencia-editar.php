<?php
require_once "config.inc.php";

$id = $_POST['id'];
$cliente = $_POST['cliente'];
$tecnico = $_POST['tecnico'];
$data_inicio = $_POST['data_inicio'];
$hora_inicio = $_POST['hora_inicio'];
$data_fim = $_POST['data_fim'];
$hora_fim = $_POST['hora_fim'];
$motivo = $_POST['motivo'];
$status = $_POST['status'];

$sql = "UPDATE ocorrencias SET
        cliente = '$cliente',
        tecnico = '$tecnico',
        data_inicio = '$data_inicio',
        inicio = '$hora_inicio',
        data_fim = '$data_fim',
        fim = '$hora_fim',
        motivo = '$motivo',
        status_ocorrencia = '$status'
        WHERE id = '$id'";

if(mysqli_query($conexao, $sql)){
    echo "<script>alert('Ocorrência atualizada com sucesso!'); window.location.href='../area-gestor.php';</script>";
} else {
    echo "<script>alert('Erro ao atualizar!'); window.location.href='../area-gestor.php';</script>";
}
?>