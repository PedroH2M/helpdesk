<?php

    require_once "config.inc.php";

    $id = $_GET['id'];
    $sql = "SELECT * FROM usuarios WHERE id = $id";

    $r = mysqli_query($conexao, $sql);
    $dados = mysqli_fetch_assoc($r);

    echo json_encode($dados);

?>