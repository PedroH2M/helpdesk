<?php

require_once "config.inc.php";

$id = $_GET['id'];

$sql = "DELETE FROM usuarios WHERE id = $id";

if(mysqli_query($conexao, $sql)){
    echo "<script>alert('Funcionário excluído com sucesso!'); window.location.href='../area-gestor.php';</script>";
} else {
    echo "<script>alert('Erro ao excluir!'); window.location.href='../area-gestor.php';</script>";
}

?>