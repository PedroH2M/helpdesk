<?php

    require_once 'config.inc.php';

    $nome = $_REQUEST['nome']; 
    $matricula = $_REQUEST['matricula']; 
    $email = $_REQUEST['email']; 
    $funcao = $_REQUEST['funcao'];
    $usuario = $_REQUEST['usuario'];
    $senha_usuario = $_REQUEST['senha'];

    $sql = "INSERT INTO usuarios (nome, matricula, email, funcao, usuario, senha_usuario) 
            VALUES ('$nome', '$matricula', '$email', '$funcao', '$usuario', '$senha_usuario')";

    if(mysqli_query($conexao, $sql)){
        header("Location: ../area-gestor.php");
    }else{
        echo "<h2>Erro ao cadastrar</h2>";
    }

    mysqli_close($conexao);
    
?>