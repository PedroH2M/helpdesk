<?php

    require_once "config.inc.php";

    $id = $_GET['id'];

    $sql = "SELECT * FROM ocorrencias WHERE id = $id";
    $result = mysqli_query($conexao, $sql);

    $dados = mysqli_fetch_assoc($result);

    echo json_encode($dados);

?>