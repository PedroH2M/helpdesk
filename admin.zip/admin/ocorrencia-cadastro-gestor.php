<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrado</title>
    <link rel="stylesheet" href="/css/ocorrencia-cadastrada.css">
</head>
<body>
    <?php

    require_once 'config.inc.php';

    $cliente = $_REQUEST['cliente'];
    $tecnico = $_REQUEST['tecnico'];
    $data_inicio = $_REQUEST['data_inicio'];
    $hora_inicio = $_REQUEST['hora_inicio'];
    $data_fim = $_REQUEST['data_fim'];
    $hora_fim = $_REQUEST['hora_fim'];
    $motivo = $_REQUEST['motivo'];
    $status = $_REQUEST['status'];

    $sql = "INSERT INTO ocorrencias (cliente, tecnico, data_inicio, inicio, data_fim, fim, motivo, status_ocorrencia) 
            VALUES ('$cliente', '$tecnico','$data_inicio','$hora_inicio', '$data_fim', '$hora_fim', '$motivo', '$status')";

    if(mysqli_query($conexao, $sql)){
        header("Location: ../area-gestor.php");
    }else{
        echo "<h2>Erro ao cadastrar</h2>";
    }

        
    mysqli_close($conexao);

?>
</body>
</html>