<?php

    require_once "config.inc.php";

    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $documento = $_POST['documento'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];

    $sql = "UPDATE clientes SET
            nome = '$nome',
            documento = '$documento',
            email = '$email',
            telefone = '$telefone'
            WHERE id = '$id'";

    if(mysqli_query($conexao, $sql)){
        echo "<script>alert('Cliente atualizado com sucesso!'); window.location.href='../area-gestor.php';</script>";
    } else {
        echo "<script>alert('Erro ao atualizar!'); window.location.href='../area-gestor.php';</script>";
    }

?>