<?php

    require_once 'config.inc.php';

    $nome = $_REQUEST['nome'];
    $documento = $_REQUEST['documento'];
    $email = $_REQUEST['email'];
    $telefone = $_REQUEST['telefone'];

    $sql = "INSERT INTO clientes (nome, documento, email, telefone) 
            VALUES ('$nome', '$documento', '$email', '$telefone')";

    if(mysqli_query($conexao, $sql)){
        header("Location: ../area-gestor.php");
    }else{
        echo "<h2>Erro ao cadastrar</h2>";
    }

    mysqli_close($conexao);

?>
